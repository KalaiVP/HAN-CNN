import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import spacy
import pickle
#python -m spacy download en_core_web_sm ------ in terminal
# Download NLTK resources
nltk.download('punkt')
nltk.download('stopwords')

nlp = spacy.load("en_core_web_sm")

with open('bert_tokens.pkl', 'rb') as file:
    bert_tokens = pickle.load(file)

ATE = []
for tokens in bert_tokens:

    # Remove stop words
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [word for word in tokens if word.lower() not in stop_words]

    # Part-of-speech tagging with spaCy
    pos_tagged_text = nlp(' '.join(filtered_tokens))

    # Extract aspect terms (nouns and adjectives)
    aspect_terms = []
    for token in pos_tagged_text:
        if token.pos_ in ['NOUN', 'ADJ']:  # Consider only nouns and adjectives
            aspect_terms.append(token.text)
    ATE.append(aspect_terms)

with open('aspect_terms.pkl', 'wb') as file:
    pickle.dump(ATE, file)
