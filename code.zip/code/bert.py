from transformers import BertTokenizer
import pandas as pd
import pickle
import numpy as np
# Load the BERT tokenizer
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
data = pd.read_csv('amazon_reviews.csv')
target = np.array(data['overall'])
np.save('target',target)

# Example text to tokenize
text_list = data['reviewText'].values.tolist()
bert_tokens = []
for text in text_list:
    try:

        # Tokenize the text
        tokens = tokenizer.tokenize(text)
        bert_tokens.append(tokens)
    except:
        pass



with open('bert_tokens.pkl', 'wb') as file:
    pickle.dump(bert_tokens, file)