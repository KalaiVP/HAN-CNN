import HAN
import tensorflow as tf
import numpy as np
import fuse_regress
import CNN


def sent_anal(inp_data,data,lab,tr, PRE, REC, F1):

    #------  HAN model    ----------------------------
    l1 = HAN.classify(inp_data, lab, tr)

    #----- HAN-F-CNN layer  ------------------

    #------ weight1
    opt = tf.keras.optimizers.RMSprop(learning_rate=0.001)
    m = tf.keras.models.Sequential([tf.keras.layers.Dense(1)])
    m.compile(opt, loss='mse')
    m.fit(data, lab)  # Training.
    w = np.mean(m.get_weights()[0])

    F = data[:, 0:8]
    TF_IDF_feat = data[:, 8]  ### TFIDF_feat


    y = [] ## output for t-th interval
    for j in range(F.shape[1]):
        y.append(F[:, j] * w[j][0])

    y1 = []  ## output for (t-1)-th interval
    for j in range(len(TF_IDF_feat)):
        y1.append(TF_IDF_feat[j] * w[j][0])


    y = np.resize(np.array(y), (len(l1), 1))
    y1 = np.resize(np.array(y1), (len(l1), 1))


    #--------- applyig fractional concept
    h = 0.5   #--- constant
    fus = h* y + 0.5 * h*y1 + (1/6)*(1-h)*l1

    #--------------         regression

    o2 = fuse_regress.classify(data, fus, lab)

    #--------   CNN layer

    o3,target =  CNN.CNN(o2,lab,tr)
    predict = o3

    uni = np.unique(target)
    tp, tn, fn, fp = 0, 0, 0, 0  # unique label
    for i1 in range(len(uni)):
        c = uni[i1]
        for i in range(len(target)):

            if (target[i] == c and predict[i] == c):
                tp = tp + 1
            if (target[i] != c and predict[i] != c):
                tn = tn + 1
            if (target[i] == c and predict[i] != c):
                fn = fn + 1
            if (target[i] != c and predict[i] == c):
                fp = fp + 1
    tp = tn / len(uni)
    fn = fn / len(uni)

    pre = tp / (tp + fp)
    rec = tp / (tp + fn)
    f_m = 2 * ((pre * rec) / (pre + rec))

    PRE.append(pre)
    REC.append(rec)
    F1.append(f_m)