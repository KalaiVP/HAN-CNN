from tensorflow.keras.layers import Input, Embedding, Dense, LSTM, Bidirectional, Concatenate, Flatten, Activation, Dot, Reshape, \
    Softmax

from keras.layers import Dense, LSTM, GRU, Conv1D, MaxPooling1D, Flatten, Concatenate, Input, Reshape
from sklearn.model_selection import train_test_split
import numpy as np
from keras.models import Model
from tensorflow.keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences

def build_han_model(max_sentence_length, max_words_per_sentence, vocab_size, embedding_dim, num_classes):
    # Word level inputs
    word_input = Input(shape=(max_sentence_length,))

    # Word embedding layer
    word_embedding = Embedding(input_dim=vocab_size, output_dim=embedding_dim)(word_input)

    # Bidirectional GRU for word encoding
    word_gru = Bidirectional(LSTM(units=64, return_sequences=True))(word_embedding)

    # Attention mechanism for word-level
    word_context_vector = Dense(1, activation='tanh')(word_gru)
    word_attention_weights = Activation('softmax')(word_context_vector)
    word_attention_weights = Reshape((max_sentence_length,))(word_attention_weights)
    word_attention_weights = Dot(axes=1)([word_attention_weights, word_gru])

    # Sentence representation
    sentence_representation = Dense(64, activation='tanh')(word_attention_weights)

    # Sentence level inputs
    sentence_input = Input(shape=(max_words_per_sentence,))

    # Sentence embedding layer
    sentence_embedding = Embedding(input_dim=vocab_size, output_dim=embedding_dim)(sentence_input)

    # Bidirectional GRU for sentence encoding
    sentence_gru = Bidirectional(LSTM(units=64, return_sequences=True))(sentence_embedding)

    # Attention mechanism for sentence-level
    sentence_context_vector = Dense(1, activation='tanh')(sentence_gru)
    sentence_attention_weights = Activation('softmax')(sentence_context_vector)
    sentence_attention_weights = Reshape((max_words_per_sentence,))(sentence_attention_weights)
    sentence_attention_weights = Dot(axes=1)([sentence_attention_weights, sentence_gru])

    # Document representation
    document_representation = Dense(64, activation='tanh')(sentence_attention_weights)

    # Merge sentence and document representations
    merged_representation = Concatenate(axis=1)([sentence_representation, document_representation])

    # Output layer
    output = Dense(num_classes, activation='softmax')(merged_representation)

    # Define model
    model = Model(inputs=[word_input, sentence_input], outputs=output)

    return model

def classify(feat,lab,tr):
    max_length = 100  # Adjust as needed based on your data
    tokenizer = Tokenizer()  # Initialize the tokenizer

    text_list = feat.values.tolist()
    tokenizer.fit_on_texts(feat)  # Fit tokenizer on the text data

    # Tokenize the text
    tokenized_text = tokenizer.texts_to_sequences(text_list)
    # Pad sequences to a fixed length
    padded_sequences = pad_sequences(tokenized_text, maxlen=max_length, padding='post', truncating='post')
    # Convert to numpy array
    X = np.array(padded_sequences)


    y = lab
    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=tr)
    predict = []
    for i in range(len(y_train)): predict.append(y_train[i][0])

    max_sentence_length = X_train.shape[1]
    max_words_per_sentence = X_train.shape[1]
    vocab_size = 10000
    embedding_dim = 100
    num_classes = len(np.unique(y_train))

    model = build_han_model(max_sentence_length, max_words_per_sentence, vocab_size, embedding_dim, num_classes)

    # Compile the model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

    # Train the model
    model.fit([X_train,X_train], y_train, epochs=50, batch_size=64, validation_split=0.2)

    pred = model.predict([X_test,X_test])




    return pred
