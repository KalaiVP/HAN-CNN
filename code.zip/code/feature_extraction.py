import pickle
import numpy as np
import nltk
import re
from sklearn.feature_extraction.text import TfidfVectorizer


import spacy
import pickle
#python -m spacy download en_core_web_sm ------ in terminal
# Download NLTK resources
nltk.download('punkt')
nltk.download('stopwords')

nlp = spacy.load("en_core_web_sm")

with open('aspect_terms.pkl', 'rb') as file:
    aspect_terms = pickle.load(file)

F = []
for term in aspect_terms:
    sentence = ' '.join(term)


    def extract_features(text):
        # Count number of question marks
        num_question_marks = text.count('?')


        # Count number of punctuation marks
        num_punctuation_marks = len(re.findall(r'[^\w\s]', text))

        # Count number of hashtags
        num_hashtags = text.count('#')

        # Count number of all-caps words
        num_all_caps = sum(1 for word in text.split() if word.isupper())

        # Count number of emoticons
        num_emoticons = len(re.findall(r'(?::|;|=)(?:-)?(?:\)|\(|D|P)', text))

        # Detect negation words
        negation_words = re.findall(r'\b(not|no|never)\b', text.lower())

        # Detect elongated units
        elongated_units = re.findall(r'\b(\S*?)(.)\2{2,}\b', text)

        # Bag of units (words)
        bag_of_units = re.findall(r'\b\w+\b', text)

        # Combine all features into a list
        features = [num_question_marks, num_punctuation_marks,
                    num_hashtags, num_all_caps, num_emoticons, len(negation_words),
                    len(elongated_units), len(bag_of_units)]

        return features

    k = extract_features(sentence)
    # Extract features for each sentence
    tfidf_vectorizer = TfidfVectorizer()
    tfidf_matrix = tfidf_vectorizer.fit_transform(term).toarray()

    feat = k + [np.mean(tfidf_matrix)]
    F.append(feat)
F = np.array(F)
np.save('feat.npy', F)