import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

def classify(Fea,L,label):
    L = np.resize(L,(len(Fea),1))
    Data=np.concatenate((Fea,L),axis=1)


    reg=LinearRegression().fit(Data, label)
    Prediction=(reg.predict(Data)).flatten()
    Prediction = Prediction.astype(int)


    return Prediction
