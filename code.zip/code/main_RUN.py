import pandas as pd
import numpy as np
import Proposed_HAN_CNN

#==========================  for varying training data  ===================================================
tr = 0.5
#--- initialize empty list for appending values
PRE, REC, F1 = [], [], []
for i in range(5):
    data = pd.read_csv('amazon_reviews.csv')
    #------ input review data
    inp_data = data['reviewText']



    #----- load the saved feature extracted data
    F = np.load('feat.npy')
    # --- load target file
    target = np.load('target.npy')

    #----- proposed HAN-CNN model for sentiment analysis
    Proposed_HAN_CNN.sent_anal(inp_data, F, target, tr, PRE, REC, F1)

    tr += 0.1


print(PRE,REC,F1)

# ======================== for varying k-fold data ================================
kf = 5
# --- initialize empty list for appending values
PRE, REC, F1 = [], [], []
for i in range(5):
    data = pd.read_csv('amazon_reviews.csv')
    # ------ input review data
    inp_data = data['reviewText']

    # ----- load the saved feature extracted data
    F = np.load('feat.npy')
    # --- load target file
    target = np.load('target.npy')
    tr = (kf - 1) / kf

    # ----- proposed HAN-CNN model for sentiment analysis
    Proposed_HAN_CNN.sent_anal(inp_data, F, target, tr, PRE, REC, F1)

    kf += 1

print(PRE, REC, F1)

